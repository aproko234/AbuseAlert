﻿using AbuseAlert.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AbuseAlert.Services
{
    public class MockDataStore : IDataStore<Item>
    {
        readonly List<Item> items;

        public MockDataStore()
        {
            items = new List<Item>()
            {
                new Item { Id = Guid.NewGuid().ToString(), Text = "Report Abuse", Description="Initiate (audiovisual) recording for unfolding event around you, which can either be transmitted simultaneously or stored on your phone for later transmission." },
                //new Item { GroupTag = "1", Id = Guid.NewGuid().ToString(), Text = "Record Audio", Description="Initiate (audio) recording for unfolding event around you for storage on your phone for later transmission." },
                //new Item { GroupTag = "1", Id = Guid.NewGuid().ToString(), Text = "Take a Photo", Description="Take one (or more) picture(s) for unfolding event around you for storage on your phone for later transmission." },
                //new Item { GroupTag = "1", Id = Guid.NewGuid().ToString(), Text = "Record Video", Description="Initiate (visual) recording for unfolding event around you for storage on your phone for later transmission." },
                //new Item { GroupTag = "1", Id = Guid.NewGuid().ToString(), Text = "Watch a LiveStream", Description="Watch (audiovisual) recording for unfolding event sent to you via the internet." },
                //new Item { GroupTag = "1", Id = Guid.NewGuid().ToString(), Text = "Broadcast a LiveStream", Description="Initiate (audiovisual) recording for unfolding event around you, which can be transmitted simultaneously." },
                new Item { Id = Guid.NewGuid().ToString(), Text = "RED Zone", Description="View or manage (if your are the Admin) dangerous areas that have been automatically identified by the app or manually captured (by the Admin)." },
                //new Item { GroupTag = "2", Id = Guid.NewGuid().ToString(), Text = "View RED Zone", Description="View dangerous areas that have been automatically identified by the app or manually captured (by the Admin)." },
                //new Item { GroupTag = "2", Id = Guid.NewGuid().ToString(), Text = "Manage RED Zone", Description="Manage (Admin ONLY) dangerous areas that have been automatically identified by the app or manually captured (by the Admin)." },
                new Item { Id = Guid.NewGuid().ToString(), Text = "Location Inquiry", Description="Make use of GPS to determine your current location." },
                new Item { Id = Guid.NewGuid().ToString(), Text = "Notify", Description="Notify specific people of your present situation." },
                new Item { Id = Guid.NewGuid().ToString(), Text = "Voice2Text", Description="Voice to text translator." },
                new Item { Id = Guid.NewGuid().ToString(), Text = "Support & Counselling", Description="You can either browse through our recommended tips of what to do before or after an abuse has occured or Chat with a representative for support and/or counselling." },
                //new Item { GroupTag = "6", Id = Guid.NewGuid().ToString(), Text = "Support Tips", Description="Browse through our recommended Support tips of how to use this app." },
                //new Item { GroupTag = "6", Id = Guid.NewGuid().ToString(), Text = "Counselling Tips", Description="Browse through our recommended Counselling tips of what to do before or after an abuse has occured." },
                //new Item { GroupTag = "6", Id = Guid.NewGuid().ToString(), Text = "Chat", Description="Chat with a representative for support and/or counselling." },
                new Item { Id = Guid.NewGuid().ToString(), Text = "Options", Description="Setup and configure several settings for the app." }
            };
        }

        public async Task<bool> AddItemAsync(Item item)
        {
            items.Add(item);

            return await Task.FromResult(true);
        }

        public async Task<bool> UpdateItemAsync(Item item)
        {
            var oldItem = items.Where((Item arg) => arg.Id == item.Id).FirstOrDefault();
            items.Remove(oldItem);
            items.Add(item);

            return await Task.FromResult(true);
        }

        public async Task<bool> DeleteItemAsync(string id)
        {
            var oldItem = items.Where((Item arg) => arg.Id == id).FirstOrDefault();
            items.Remove(oldItem);

            return await Task.FromResult(true);
        }

        public async Task<Item> GetItemAsync(string id)
        {
            return await Task.FromResult(items.FirstOrDefault(s => s.Id == id));
        }

        public async Task<IEnumerable<Item>> GetItemsAsync(bool forceRefresh = false)
        {
            return await Task.FromResult(items);
        }
    }
}