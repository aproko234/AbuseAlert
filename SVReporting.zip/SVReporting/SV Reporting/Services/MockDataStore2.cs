﻿using AbuseAlert.Models;
//using AbuseAlert.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AbuseAlert.Services
{
    public class MockDataStore2 : IDataStore<Item>
    {
        readonly List<Item> Items;

        bool IsBusy = false;

        public MockDataStore2()
        {
            try
            {
                if (IsBusy)
                    return;

                IsBusy = true;

                //Items.Clear();

                List<Room> Hotel1rooms = new List<Room>()
                {
                    new Room("Record Audio", 1), new Room("Take a Photo", 1), new Room("Record Video", 1), new Room("Watch a LiveStream", 1), new Room("Broadcast a LiveStream", 1)
                };
                List<Room> Hotel2rooms = new List<Room>()
                {
                    new Room("View RED Zone", 1), new Room("Manage RED Zone", 1)
                };
                List<Room> Hotel3rooms = new List<Room>()
                {
                };
                List<Room> Hotel4rooms = new List<Room>()
                {
                };
                List<Room> Hotel5rooms = new List<Room>()
                {
                };
                List<Room> Hotel6rooms = new List<Room>()
                {
                    new Room("Support Tips", 1), new Room("Counselling Tips", 1), new Room("Chat", 1)
                };
                List<Room> Hotel7rooms = new List<Room>()
                {

                };

                List<Hotel> Items = new List<Hotel>()
                {
                    new Hotel("Report Abuse", Hotel1rooms), new Hotel("RED Zone", Hotel2rooms), new Hotel("Location Inquiry", Hotel3rooms), new Hotel("Notify", Hotel4rooms), new Hotel("Voice2Text", Hotel5rooms), new Hotel("Support & Counselling", Hotel6rooms), new Hotel("Options", Hotel7rooms)
                };

                //if (Items != null && Items.Count > 0)
                //{
                    //foreach (var hotel in Items)
                    //    Items.Add(new ViewModels.HotelViewModel(hotel));
                //}
                //else { IsEmpty = true; }

            }
            catch (Exception ex)
            {
                IsBusy = false;
                Console.WriteLine(ex);
            }
            finally
            {
                IsBusy = false;
            }

        }

        public async Task<bool> AddItemAsync(Item item)
        {
            Items.Add(item);

            return await Task.FromResult(true);
        }

        public async Task<bool> UpdateItemAsync(Item item)
        {
            var oldItem = Items.Where((Item arg) => arg.Id == item.Id).FirstOrDefault();
            Items.Remove(oldItem);
            Items.Add(item);

            return await Task.FromResult(true);
        }

        public async Task<bool> DeleteItemAsync(string id)
        {
            var oldItem = Items.Where((Item arg) => arg.Id == id).FirstOrDefault();
            Items.Remove(oldItem);

            return await Task.FromResult(true);
        }

        public async Task<Item> GetItemAsync(string id)
        {
            return await Task.FromResult(Items.FirstOrDefault(s => s.Id == id));
        }

        public async Task<IEnumerable<Item>> GetItemsAsync(bool forceRefresh = false)
        {
            return await Task.FromResult(Items);
        }
    }
}