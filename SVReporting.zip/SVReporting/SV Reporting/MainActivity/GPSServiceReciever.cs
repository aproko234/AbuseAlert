﻿namespace MainActivity
{
    internal class GPSServiceReciever
    {
    }
}