﻿using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using Plugin.Media;
using Plugin.Media.Abstractions;
using System.Threading.Tasks;

namespace AbuseAlert.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class Report_Abuse: ContentPage
	{
		//public Xamarin.Essentials.Location _location;
		//readonly AudioRecorderService recorder;
		//readonly AudioPlayer player;

		public Report_Abuse()
		{
			InitializeComponent();

		}

		void Audio_Clicked(object sender, EventArgs e)
		{
			if (Device.RuntimePlatform == Device.iOS)
			{
				// https://developer.apple.com/library/ios/featuredarticles/iPhoneURLScheme_Reference/MapLinks/MapLinks.html
				//await Launcher.OpenAsync("http://maps.apple.com/?daddr=San+Francisco,+CA&saddr=cupertino");
			}
			else if (Device.RuntimePlatform == Device.Android)//if ( ||  || item.Text == "Watch a LiveStream" || item.Text == "Broadcast a LiveStream")
			{
				var detailPage = new NavigationPage(new AudioRecorder());

				App.Current.MainPage.Navigation.PushModalAsync(detailPage);

				return;
			}
			else if (Device.RuntimePlatform == Device.UWP)
			{
				//await Launcher.OpenAsync("bingmaps:?rtp=adr.394 Pacific Ave San Francisco CA~adr.One Microsoft Way Redmond WA 98052");
			}
		}

		async void Photo_Clicked(object sender, EventArgs e)
        {
			await Photo_ClickedAsync(this, null);
        }

		async Task Photo_ClickedAsync(object sender, EventArgs e)
		{
			if (Device.RuntimePlatform == Device.iOS)
			{
				// https://developer.apple.com/library/ios/featuredarticles/iPhoneURLScheme_Reference/MapLinks/MapLinks.html
				//await Launcher.OpenAsync("http://maps.apple.com/?daddr=San+Francisco,+CA&saddr=cupertino");
			}
			else if (Device.RuntimePlatform == Device.Android)//if ( ||  || item.Text == "Watch a LiveStream" || item.Text == "Broadcast a LiveStream")
			{
				if (CrossMedia.Current.IsCameraAvailable && CrossMedia.Current.IsTakePhotoSupported)
				{
					//takePhoto.Clicked += async (sender, args) =>
					{
						if (!CrossMedia.Current.IsCameraAvailable || !CrossMedia.Current.IsTakePhotoSupported)
						{
							await App.Current.MainPage.DisplayAlert("No Camera", ":( No camera available.", "OK");
							return;
						}

					};

					try
                    {
						await CrossMedia.Current.Initialize();

						var file = await CrossMedia.Current.TakePhotoAsync(new StoreCameraMediaOptions
						{
							Directory = "AAPictures",
							Name = $"{DateTime.UtcNow}.mp4",

							PhotoSize = PhotoSize.Custom,
							CustomPhotoSize = 90,
							CompressionQuality = 92,
							SaveToAlbum = true
						});

						if (file == null)
							return;

						//Image.Source = ImageSource.FromStream(() =>
						//{
						//var stream = file.GetStream();
						//file.Dispose();
						//return stream;
						//});

						await App.Current.MainPage.DisplayAlert("Picture Location", file.AlbumPath, "OK");
					}
					catch
                    {
						await App.Current.MainPage.DisplayAlert("AbuseAlert", "One or more Android device permission(s) that needed to be granted was (or were) denied. Unable to proceed with current task for now...", "OK");
						//return;
					}
				}
			}
			else if (Device.RuntimePlatform == Device.UWP)
			{
				//Launcher.OpenAsync("bingmaps:?rtp=adr.394 Pacific Ave San Francisco CA~adr.One Microsoft Way Redmond WA 98052");
			}
		}

		async void Video_Clicked(object sender, EventArgs e)
		{
			await Video_ClickedAsync(this, null);	
		}
		
		async Task Video_ClickedAsync(object sender, EventArgs e)
		{
			if (Device.RuntimePlatform == Device.iOS)
			{
				// https://developer.apple.com/library/ios/featuredarticles/iPhoneURLScheme_Reference/MapLinks/MapLinks.html
				//Launcher.OpenAsync("http://maps.apple.com/?daddr=San+Francisco,+CA&saddr=cupertino");
			}
			else if (Device.RuntimePlatform == Device.Android)//if ( ||  || item.Text == "Watch a LiveStream" || item.Text == "Broadcast a LiveStream")
			{
				if (CrossMedia.Current.IsCameraAvailable && CrossMedia.Current.IsTakeVideoSupported)
				{
					if (!CrossMedia.Current.IsCameraAvailable || !CrossMedia.Current.IsTakeVideoSupported)
					{
						await App.Current.MainPage.DisplayAlert("No Camera", ":( No camera avaialble.", "OK");
						return;
					}
                    
					try
                    {
						await CrossMedia.Current.Initialize();

						var file = await CrossMedia.Current.TakeVideoAsync(new StoreVideoOptions
						{
							Directory = "AAVideos",
							Name = $"{DateTime.UtcNow}.mp4",

							//PhotoSize = PhotoSize.Custom,
							//CustomPhotoSize = 90,
							//CompressionQuality = 92,

							DesiredLength = new TimeSpan(300), //0, seconds),
							CompressionQuality = 80,
							Quality = VideoQuality.Medium,
							SaveToAlbum = true
						});

						if (file == null)
							return;

						//Image.Source = ImageSource.FromStream(() =>
						//{
						//var stream = file.GetStream();
						//file.Dispose();
						//return stream;
						//});

						await App.Current.MainPage.DisplayAlert("Video Location", file.AlbumPath, "OK");
					}
					catch
                    {
						await App.Current.MainPage.DisplayAlert("AbuseAlert", "One or more Android device permission(s) that needed to be granted was (or were) denied. Unable to proceed with current task for now...", "OK");
						//return;
					}
				}
			}
			else if (Device.RuntimePlatform == Device.UWP)
			{
				//Launcher.OpenAsync("bingmaps:?rtp=adr.394 Pacific Ave San Francisco CA~adr.One Microsoft Way Redmond WA 98052");
			}
			
		}

		void LiveStream_Clicked(object sender, EventArgs e)
		{
			//_ = UploadAudioAsync();
			if (Device.RuntimePlatform == Device.iOS)
			{
				// https://developer.apple.com/library/ios/featuredarticles/iPhoneURLScheme_Reference/MapLinks/MapLinks.html
				//await Launcher.OpenAsync("http://maps.apple.com/?daddr=San+Francisco,+CA&saddr=cupertino");
			}
			else if (Device.RuntimePlatform == Device.Android)//if ( ||  || item.Text == "Watch a LiveStream" || item.Text == "Broadcast a LiveStream")
			{
				var detailPage = new NavigationPage(new VideoRecordPage());

				App.Current.MainPage.Navigation.PushModalAsync(detailPage);

				return;
			}
			else if (Device.RuntimePlatform == Device.UWP)
			{
				//await Launcher.OpenAsync("bingmaps:?rtp=adr.394 Pacific Ave San Francisco CA~adr.One Microsoft Way Redmond WA 98052");
			}
			
		}

		void Broadcast_Clicked(object sender, EventArgs e)
		{
			//_ = UploadAudioAsync();
		}
	}


}