﻿using AbuseAlert.Models;
using AbuseAlert.ViewModels;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace AbuseAlert.Views
{
    public partial class VideoRecordPage : ContentPage
    {
        public Item Item { get; set; }

        public VideoRecordPage()
        {
            InitializeComponent();
            BindingContext = new VideoRecordViewModel();
        }
    }
}