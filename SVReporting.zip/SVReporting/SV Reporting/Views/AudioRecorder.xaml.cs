﻿using System;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using Plugin.AudioRecorder;
using System.Net;
using System.Net.Mail;
using Xamarin.Essentials;
using System.Collections.Generic;

namespace AbuseAlert.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AudioRecorder : ContentPage
    {
		public Xamarin.Essentials.Location _location;
        readonly AudioRecorderService recorder;
        readonly AudioPlayer player;

        public AudioRecorder()
        {
            InitializeComponent();

            recorder = new AudioRecorderService
            {
                StopRecordingAfterTimeout = true,
                TotalAudioTimeout = TimeSpan.FromSeconds(15),
                AudioSilenceTimeout = TimeSpan.FromSeconds(2)
            };

            player = new AudioPlayer();
            player.FinishedPlaying += Player_FinishedPlaying;
		}

		async void Record_Clicked(object sender, EventArgs e)
		{
			await RecordAudio();
		}

		async Task RecordAudio()
		{
			try
			{
				if (!recorder.IsRecording) //Record button clicked
				{
					recorder.StopRecordingOnSilence = TimeoutSwitch.IsToggled;

					RecordButton.IsEnabled = false;
					PlayButton.IsEnabled = false;
					UploadButton.IsEnabled = false;

					//start recording audio
					var audioRecordTask = await recorder.StartRecording();

					RecordButton.Text = "Stop Recording";
					RecordButton.IsEnabled = true;

					await audioRecordTask;

					RecordButton.Text = "Record";
					PlayButton.IsEnabled = true;
					UploadButton.IsEnabled = true;
				}
				else //Stop button clicked
				{
					RecordButton.IsEnabled = false;

					//stop the recording...
					await recorder.StopRecording();

					RecordButton.IsEnabled = true;
				}
			}
			catch (Exception ex)
			{
				//blow up the app!
				throw ex;
			}
		}

		void Play_Clicked(object sender, EventArgs e)
		{
			PlayAudio();
		}

		void PlayAudio()
		{
			try
			{
				var filePath = recorder.GetAudioFilePath();

				if (filePath != null)
				{
					PlayButton.IsEnabled = false;
					RecordButton.IsEnabled = false;
					UploadButton.IsEnabled = false;

					player.Play(filePath);
				}
			}
			catch (Exception ex)
			{
				//blow up the app!
				throw ex;
			}
		}

		void Player_FinishedPlaying(object sender, EventArgs e)
		{
			PlayButton.IsEnabled = true;
			RecordButton.IsEnabled = true;
			UploadButton.IsEnabled = true;
		}

		void Upload_Clicked(object sender, EventArgs e)
		{
            _ = UploadAudioAsync();
		}

        private async Task UploadAudioAsync()
		{
			try
			{
				var filePath = recorder.GetAudioFilePath();

				//if (filePath != null)
				{
					PlayButton.IsEnabled = false;
					RecordButton.IsEnabled = false;
					UploadButton.IsEnabled = false;

                    int v = await SendEmailAsync(this, null); //BtnSend_Clicked(this, null); // 

					if (v != 0) 
					{
						Upload_Finished(this, null);

						if (v == 1)
						{
							await DisplayAlert("AbuseAlert", "Your audio upload was successfully mailed.", "OK");
						}
						else 
						{
							await DisplayAlert("AbuseAlert", "Your audio upload was NOT successfully mailed.", "OK");
						}
						//PlayButton.IsEnabled = true;
						//RecordButton.IsEnabled = true;
						//UploadButton.IsEnabled = true;
					}
				}
			}
			catch (Exception ex)
			{
				//blow up the app!
				throw ex;
			}
		}

		void Upload_Finished(object sender, EventArgs e)
		{
			try 
			{
				PlayButton.IsEnabled = true;
				RecordButton.IsEnabled = true;
				UploadButton.IsEnabled = true;

			}
			catch (Exception ex)
            {
				Console.WriteLine(ex.Message); 
            }
		}

		private async Task<int> SendEmailAsync(object sender, EventArgs e)
		{
			var status = await Permissions.CheckStatusAsync<Permissions.LocationWhenInUse>();

			if (status == PermissionStatus.Granted)
			{
				var locationFromPhone = await GetLocationFromPhone().ConfigureAwait(false);

				_location = locationFromPhone;
			}
			else
			{
				status = await Permissions.RequestAsync<Permissions.LocationWhenInUse>();

				if (status == PermissionStatus.Denied && DeviceInfo.Platform == DevicePlatform.iOS)
				{
					// Prompt the user to turn on in settings
					await DisplayAlert("AbuseAlert", "Permission to view current location was not granted. Please, turn on in settings and return to retry this function...", "OK");

					// On iOS once a permission has been denied it may not be requested again from the application
					return 2;
				}

				if (Permissions.ShouldShowRationale<Permissions.LocationWhenInUse>())
				{
					// Prompt the user with additional information as to why the permission is needed
					await DisplayAlert("AbuseAlert", "Without granting permission to view current location, Abuse Alert will not be able to proceed with the requested command...", "OK");

					return 2;
				}

				if (status == PermissionStatus.Denied)
					return 2;
				else
				{
					var locationFromPhone = await GetLocationFromPhone().ConfigureAwait(false);

					_location = locationFromPhone;
				}
            }
		
            try
			{
				string subject = "Abuse Alert (TM) Notification";

				string body = "An audio recording has just been sent to you as an attachment from the Abuse Alert (TM) Mobile App. " +
							  "You are receiving this message because your email address is among those picked for this exercise. " +
							  "This audio recording was done at this location: https://maps.google.com/maps?q=(" + _location.Latitude.ToString() + "," + _location.Longitude.ToString() + "). " +
							  "If you would like to stop receiving such messages in the future, kindly contact the App Admin ASAP. Thanks.";

				var mail = new MailMessage();
				var smtpServer = new SmtpClient("mail.234Aproko.com", 25); //"smtp.gmail.com", 587);

				mail.From = new MailAddress("info@234Aproko.com"); //"softworldng@gmail.com");
				mail.To.Add("softworldng@gmail.com"); //1
				mail.To.Add("softworldng@live.com"); //2
				mail.To.Add("md.idiake.ng@outlook.com"); //3
				mail.To.Add("md.idiake.us@outlook.com"); //4
				mail.To.Add("md.idiake.ng@gmail.com"); //5
				mail.To.Add("softworldng@yahoo.com"); //6
				mail.To.Add("md.idiake.us@gmail.com"); //7

				mail.Subject = subject;
				mail.Body = body;

				Attachment attachment;
				attachment = new Attachment(recorder.GetAudioFilePath());
				mail.Attachments.Add(attachment);

				smtpServer.Credentials = new NetworkCredential("info@234Aproko.com", "Ad10me72$#@"); //softworldng", "Abcd1234%$#@");
				smtpServer.UseDefaultCredentials = false;

				smtpServer.EnableSsl = false; // true;
				smtpServer.Send(mail);

				//Upload_Finished(this, null);

				return 1;
			}
			catch (Exception ex)
            {
                Console.WriteLine(ex.Message); // await DisplayAlert("AbuseAlert", ex.Message, "OK"); //"An authentication error may have occured with uploading your recorded audio via email. Pls, check that you have internet access and try again. If this issue persists, pls contact the App ADMIN ASAP...", "OK");				
				//throw ex; 
				//Upload_Finished(this, null);

				return 2;
			}

			//return 1; //Upload_Finished(this, null);

			//RecordButton.IsEnabled = true;
			//PlayButton.IsEnabled = true;
			//UploadButton.IsEnabled = true; 
		}

		Task<Xamarin.Essentials.Location> GetLocationFromPhone()
		{

			var locationTaskCompletionSource = new TaskCompletionSource<Xamarin.Essentials.Location>();

			Device.BeginInvokeOnMainThread(async () =>
			{
				locationTaskCompletionSource.SetResult(await Geolocation.GetLastKnownLocationAsync());
			});

			return locationTaskCompletionSource.Task;
		}

		public async Task<PermissionStatus> CheckAndRequestLocationPermission()
		{
			var status = await Permissions.CheckStatusAsync<Permissions.LocationWhenInUse>();

			if (status == PermissionStatus.Granted)
				return status;

			if (status == PermissionStatus.Denied && DeviceInfo.Platform == DevicePlatform.iOS)
			{
				// Prompt the user to turn on in settings
				// On iOS once a permission has been denied it may not be requested again from the application
				return status;
			}

			if (Permissions.ShouldShowRationale<Permissions.LocationWhenInUse>())
			{
				// Prompt the user with additional information as to why the permission is needed
			}

			status = await Permissions.RequestAsync<Permissions.LocationWhenInUse>();

			return status;
		}

        private async void BtnSend_Clicked(object sender, System.EventArgs e)
		{
            List<string> toAddress = new List<string>
            {
                "softworldng@live.com", // (txtTo.Text);
                "softworldng@gmail.com", // (txtTo.Text);
                "softworldng@yahoo.com", // (txtTo.Text);
                "md.idiake.us@outlook.com", // (txtTo.Text);
                "md.idiake.ng@outlook.com", // (txtTo.Text);
                "md.idiake.ng@gmail.com", // (txtTo.Text);
                "md.idiake.us@gmail.com" // (txtTo.Text);
            };

            string subject = "Abuse Alert (TM) Notification";

			string body = "An audio recording has just been sent to you as an attachment from the Abuse Alert (TM) Mobile App. " +
						  "You are receiving this message because your email address is among those picked for this exercise. " +
						  "This audio recording was done at this location: https://maps.google.com/maps?q=(" + _location.Latitude.ToString() + "," + _location.Longitude.ToString() + "). " +
						  "If you would like to stop receiving such messages in the future, kindly contact the App Admin ASAP. Thanks.";

			await SendEmail(subject, body, toAddress);
		}

		public async Task SendEmail(string subject, string body, List<string> recipients)
		{
			try
			{
				var message = new EmailMessage
				{
					Subject = subject,
					Body = body,
					To = recipients,
					//Attachments =
				};

				await Email.ComposeAsync(message);
			}
			catch (FeatureNotSupportedException fbsEx)
			{
				Console.WriteLine(fbsEx); // Email is not supported on this device  
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex); // Some other exception occurred  
			}
		}
	}
}