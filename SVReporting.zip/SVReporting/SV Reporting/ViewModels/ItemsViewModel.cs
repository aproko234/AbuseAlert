﻿using AbuseAlert.Models;
using AbuseAlert.Views;
using Plugin.Media;
using Plugin.Media.Abstractions;
using System;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Threading.Tasks;
using Xamarin.Essentials;
using Xamarin.Forms;
using Plugin.AudioRecorder;

namespace AbuseAlert.ViewModels
{
    public class ItemsViewModel : BaseViewModel
    {
        private Item _selectedItem;
        public string value;

        public Xamarin.Essentials.Location _location;

        //public string _directory = @"AAVideos";
        public string _documentsPath = "AAVideos/"; //System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyVideos) + "/";
        public string _document2Path = "AAPictures/";  //System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyPictures) + "/";

        public AudioRecorderService _recorder;

        //public string _pryDCIMPath = System.Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);

        //public string _secStore = System.getenv("SECONDARY_STORAGE");
        //public File file = new File(_secStore + "/DCIM");

        //readonly string mtyp = "Record";

        //mtyp= "Recording"

        //Value="Initialize"

        public ObservableCollection<Item> Items { get; }
        public Command LoadItemsCommand { get; }
        public Command AddItemCommand { get; }
        public Command<Item> ItemTapped { get; }

        public ItemsViewModel()
        {
            Title = "Services";
            Items = new ObservableCollection<Item>();
            LoadItemsCommand = new Command(async () => await ExecuteLoadItemsCommand());

            ItemTapped = new Command<Item>(OnItemSelected);

            AddItemCommand = new Command(OnAddItem);
        }

        Task<Xamarin.Essentials.Location> GetLocationFromPhone()
        {

            var locationTaskCompletionSource = new TaskCompletionSource<Xamarin.Essentials.Location>();

            Device.BeginInvokeOnMainThread(async () =>
            {
                locationTaskCompletionSource.SetResult(await Geolocation.GetLastKnownLocationAsync());
            });

            return locationTaskCompletionSource.Task;
        }

        public async Task<PermissionStatus> CheckAndRequestLocationPermission()
        {
            var status = await Permissions.CheckStatusAsync<Permissions.LocationWhenInUse>();

            if (status == PermissionStatus.Granted)
                return status;

            if (status == PermissionStatus.Denied && DeviceInfo.Platform == DevicePlatform.iOS)
            {
                // Prompt the user to turn on in settings
                // On iOS once a permission has been denied it may not be requested again from the application
                return status;
            }

            if (Permissions.ShouldShowRationale<Permissions.LocationWhenInUse>())
            {
                // Prompt the user with additional information as to why the permission is needed
            }

            status = await Permissions.RequestAsync<Permissions.LocationWhenInUse>();

            return status;
        }

        async Task ExecuteLoadItemsCommand()
        {
            IsBusy = true;

            try
            {
                Items.Clear();
                var items = await DataStore.GetItemsAsync(true);
                foreach (var item in items)
                {
                    Items.Add(item);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex);
            }
            finally
            {
                IsBusy = false;
            }
        }

        public void OnAppearing()
        {
            IsBusy = true;
            SelectedItem = null;
            //base..OnAppearing();
            //listViewOrderCloths.HeightRequest = model.ListOrderedCloths.Count * 100)/ 2;
        }

        public Item SelectedItem
        {
            get => _selectedItem;
            set
            {
                SetProperty(ref _selectedItem, value);
                OnItemSelected(value);
            }
        }

        private async void OnAddItem(object obj)
        {
            await Shell.Current.GoToAsync(nameof(NewItemPage));
        }

        //private async void OnAddVideo(object obj)
        //{
            //await Shell.Current.GoToAsync(nameof(VideoRecordPage));
        //}

        async void OnItemSelected(Item item)
        {
            if (item == null)
                return;

            //await App.Current.MainPage.DisplayAlert("Abuse Alert (TM)", item.Text, "OK");

            if (item.Text == "Report Abuse")
            {
                //await Shell.Current.GoToAsync($"//{nameof(AudioRecorder)}");

                var detailPage = new NavigationPage(new Report_Abuse());

                await App.Current.MainPage.Navigation.PushModalAsync(detailPage);

                return;
            }

            if (item.Text == "Notify") //Record Audio
            {
                //await Shell.Current.GoToAsync($"//{nameof(AudioRecorder)}");
                
                //var detailPage = new NavigationPage(new AudioRecorder());
                
                //await App.Current.MainPage.Navigation.PushModalAsync(detailPage);

                //return;
            }
            
            if (item.Text == "Record Audio" || item.Text == "Record Photo" || item.Text == "Record Video" || item.Text == "Watch a LiveStream" || item.Text == "Broadcast a LiveStream") //item.Text == "Report Abuse" || 
            {
                if (Device.RuntimePlatform == Device.iOS)
                {
                    // https://developer.apple.com/library/ios/featuredarticles/iPhoneURLScheme_Reference/MapLinks/MapLinks.html
                    await Launcher.OpenAsync("http://maps.apple.com/?daddr=San+Francisco,+CA&saddr=cupertino");
                }
                else if (Device.RuntimePlatform == Device.Android)//if ( ||  || item.Text == "Watch a LiveStream" || item.Text == "Broadcast a LiveStream")
                {
                    if (item.Text == "Record Photo" && CrossMedia.Current.IsCameraAvailable && CrossMedia.Current.IsTakePhotoSupported)
                    {
                        //takePhoto.Clicked += async (sender, args) =>
                        {
                            if (!CrossMedia.Current.IsCameraAvailable || !CrossMedia.Current.IsTakePhotoSupported)
                            {
                                await App.Current.MainPage.DisplayAlert("No Camera", ":( No camera available.", "OK");
                                return;
                            }

                            await CrossMedia.Current.Initialize();

                            var file = await CrossMedia.Current.TakePhotoAsync(new StoreCameraMediaOptions
                            {
                                Directory = "AAPictures",
                                Name = $"{DateTime.UtcNow}.mp4",

                                PhotoSize = PhotoSize.Custom,
                                CustomPhotoSize = 90,
                                CompressionQuality = 92,
                                SaveToAlbum = true
                            });

                            if (file == null)
                                return;

                            //Image.Source = ImageSource.FromStream(() =>
                            //{
                            //var stream = file.GetStream();
                            //file.Dispose();
                            //return stream;
                            //});

                            await App.Current.MainPage.DisplayAlert("Picture Location", file.AlbumPath, "OK");
                        };
                    }

                    //await App.Current.MainPage.DisplayAlert("File Location", _documentsPath, "OK");

                    if (item.Text == "Record Video" && CrossMedia.Current.IsCameraAvailable && CrossMedia.Current.IsTakeVideoSupported)
                    {
                        // Supply media options for saving our video after it's taken.
                        //var mediaOptions = new Plugin.Media.Abstractions.StoreCameraMediaOptions
                        //{
                        //Directory = _documentsPath, //"Videos",
                        //Name = $"{DateTime.UtcNow}.mp4",
                        //SaveToAlbum = false
                        //};

                        //await App.Current.MainPage.DisplayAlert("File Location", mediaOptions.Name, "OK");

                        // Record a video
                        //var file = await CrossMedia.Current.TakeVideoAsync((StoreVideoOptions)mediaOptions);

                        //await App.Current.MainPage.DisplayAlert("File Location", mediaOptions.Name, "OK");

                        //takePhoto.Clicked += async (sender, args) =>
                        {

                            if (!CrossMedia.Current.IsCameraAvailable || !CrossMedia.Current.IsTakeVideoSupported)
                            {
                                await App.Current.MainPage.DisplayAlert("No Camera", ":( No camera avaialble.", "OK");
                                return;
                            }

                            await CrossMedia.Current.Initialize();

                            var file = await CrossMedia.Current.TakeVideoAsync(new StoreVideoOptions
                            {
                                Directory = "AAVideos",
                                Name = $"{DateTime.UtcNow}.mp4",

                                //PhotoSize = PhotoSize.Custom,
                                //CustomPhotoSize = 90,
                                //CompressionQuality = 92,

                                DesiredLength = new TimeSpan(300), //0, seconds),
                                CompressionQuality = 80,
                                Quality = VideoQuality.Medium,
                                SaveToAlbum = true
                            });

                            if (file == null)
                                return;

                            //Image.Source = ImageSource.FromStream(() =>
                            //{
                            //var stream = file.GetStream();
                            //file.Dispose();
                            //return stream;
                            //});

                            await App.Current.MainPage.DisplayAlert("Video Location", file.AlbumPath, "OK");
                        };

                    }

                    if (_documentsPath == null)
                    {
                        var file = await CrossMedia.Current.TakeVideoAsync(new StoreVideoOptions
                        {
                            SaveToAlbum = true,
                            Directory = _documentsPath //+ _directory
                        });

                        //Get the public album path

                        if (file == null)
                            return;

                        await App.Current.MainPage.DisplayAlert("File Location", file.AlbumPath, "OK");
                    }

                }
                else if (Device.RuntimePlatform == Device.UWP)
                {
                    await Launcher.OpenAsync("bingmaps:?rtp=adr.394 Pacific Ave San Francisco CA~adr.One Microsoft Way Redmond WA 98052");
                }                
            }

            if (item.Text == "Location Inquiry")
            {
                var status = await Permissions.CheckStatusAsync<Permissions.LocationWhenInUse>();

                if (status == PermissionStatus.Granted)
                { 
                    var locationFromPhone = await GetLocationFromPhone().ConfigureAwait(false);

                    _location = locationFromPhone;
                }
                else
                {
                    status = await Permissions.RequestAsync<Permissions.LocationWhenInUse>();

                    if (status == PermissionStatus.Denied && DeviceInfo.Platform == DevicePlatform.iOS)
                    {
                        // Prompt the user to turn on in settings
                        await App.Current.MainPage.DisplayAlert("AbuseAlert", "Permission to view current location was not granted. Please, turn on in settings and return to retry this function...", "OK");
                        
                        // On iOS once a permission has been denied it may not be requested again from the application
                        return;
                    }

                    if (Permissions.ShouldShowRationale<Permissions.LocationWhenInUse>())
                    {
                        // Prompt the user with additional information as to why the permission is needed
                        await App.Current.MainPage.DisplayAlert("AbuseAlert", "Without granting permission to view current location, Abuse Alert will not be able to proceed with the requested command...", "OK");

                        return;
                    }

                    if (status == PermissionStatus.Denied)
                        return;
                    else 
                    {
                        var locationFromPhone = await GetLocationFromPhone().ConfigureAwait(false);

                        _location = locationFromPhone;
                    }

                }
            }

            // This will push the ItemDetailPage onto the navigation stack
            if (!(item.Text == "Location Inquiry") && !(item.Text == "Report Abuse"))
               await Shell.Current.GoToAsync($"{nameof(ItemDetailPage)}?{nameof(ItemDetailViewModel.ItemId)}={item.Id}");
              

            //Debug.WriteLine("Janet Ihensekhien", item.Text);

            //getProperty(ref _selectedItem, value);

            if (item.Text == "Location Inquiry")
            {
                if (Device.RuntimePlatform == Device.iOS)
                {
                    // https://developer.apple.com/library/ios/featuredarticles/iPhoneURLScheme_Reference/MapLinks/MapLinks.html
                    await Launcher.OpenAsync("http://maps.apple.com/?daddr=San+Francisco,+CA&saddr=cupertino");
                }
                else if (Device.RuntimePlatform == Device.Android)
                {
                    // opens the 'task chooser' so the user can pick Maps, Chrome or other mapping app
                    //await Launcher.OpenAsync("http://maps.google.com/?daddr=San+Francisco,+CA&saddr=Mountain+View");
                    await Launcher.OpenAsync("https://maps.google.com/maps?q=(" + _location.Latitude + "," + _location.Longitude  + ")");
                }
                else if (Device.RuntimePlatform == Device.UWP)
                {
                    await Launcher.OpenAsync("bingmaps:?rtp=adr.394 Pacific Ave San Francisco CA~adr.One Microsoft Way Redmond WA 98052");
                }
            }
        }

    }


}