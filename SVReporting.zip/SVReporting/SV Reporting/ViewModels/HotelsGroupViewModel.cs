﻿using AbuseAlert.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using Xamarin.Forms;

namespace AbuseAlert.ViewModels
{
    public class HotelsGroupViewModel : BaseViewModel2
    {
        private HotelViewModel _oldHotel;

        private ObservableCollection<HotelViewModel> items;
        public ObservableCollection<HotelViewModel> Items
        {
            get => items;

            set => SetProperty(ref items, value);
        }
      
        public Command LoadHotelsCommand { get; set; }
        public Command<HotelViewModel> RefreshItemsCommand { get; set; }

        public HotelsGroupViewModel()
        {
            items = new ObservableCollection<HotelViewModel>();
            Items = new ObservableCollection<HotelViewModel>();
            //LoadHotelsCommand = new Command(() => ExecuteLoadItemsCommandAsync());
            LoadHotelsCommand = new Command(async () => await ExecuteLoadItemsCommandAsync());
            RefreshItemsCommand = new Command<HotelViewModel>((item) => ExecuteRefreshItemsCommand(item));
        }
      
        public bool isExpanded = false;
        private void ExecuteRefreshItemsCommand(HotelViewModel item)
        {
            if (_oldHotel == item)
            {
                // click twice on the same item will hide it
                item.Expanded = !item.Expanded;
            }
            else
            {
                if (_oldHotel != null)
                {
                    // hide previous selected item
                    _oldHotel.Expanded = false;
                }
                // show selected item
                item.Expanded = true;
            }

            _oldHotel = item;
        }
        async System.Threading.Tasks.Task ExecuteLoadItemsCommandAsync()
        //void ExecuteLoadItemsCommand()
        {
            try
            {
                if (IsBusy)
                    return;
                IsBusy = true;
                Items.Clear();
                List<Room> Hotel1rooms = new List<Room>()
                {
                    new Room("Record Audio", 1), new Room("Take a Photo", 1), new Room("Record Video", 1), new Room("Watch a LiveStream", 1), new Room("Broadcast a LiveStream", 1)
                };
                List<Room> Hotel2rooms = new List<Room>()
                {
                    new Room("View RED Zone", 1), new Room("Manage RED Zone", 1)
                };
                List<Room> Hotel3rooms = new List<Room>()
                {
                };
                List<Room> Hotel4rooms = new List<Room>()
                {
                };
                List<Room> Hotel5rooms = new List<Room>()
                {
                };
                List<Room> Hotel6rooms = new List<Room>()
                {
                    new Room("Support Tips", 1), new Room("Counselling Tips", 1), new Room("Chat", 1)
                };
                List<Room> Hotel7rooms = new List<Room>()
                {

                };

                List<Hotel> items = new List<Hotel>()
                {
                    new Hotel("Report Abuse", Hotel1rooms), new Hotel("RED Zone", Hotel2rooms), new Hotel("Location Inquiry", Hotel3rooms), new Hotel("Notify", Hotel4rooms), new Hotel("Voice2Text", Hotel5rooms), new Hotel("Support & Counselling", Hotel6rooms), new Hotel("Options", Hotel7rooms)
                };

                if (items != null && items.Count > 0)
                {
                    foreach (var hotel in items)
                        Items.Add(new HotelViewModel(hotel));
                }
                else { IsEmpty = true; }

            }
            catch (Exception ex)
            {
                IsBusy = false;
                Debug.WriteLine(ex);
            }
            finally
            {
                IsBusy = false;
            }
        }
    }
}
